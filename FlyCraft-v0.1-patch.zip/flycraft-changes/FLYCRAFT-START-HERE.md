# FlyCraft starter — getting started

## What this package contains

This is a modified copy of the GFly project supplied for the FlyCraft build.
It preserves the original connectome simulation and adds a new `/flycraft/`
workspace route.

### Included in FlyCraft v0.1

- **Brain Simulator:** the original GFly baseline-room runner and its original
  connectome/worker/brain/body visualizations.
- **Voxel Room:** a new Three.js Minecraft-inspired laboratory scene. It is a
  visual prototype and is not yet connected to the simulated fly.
- **Lesson Library:** choose MP4/WebM videos and transcript files (`.srt`,
  `.vtt`, `.txt`). The files are stored in this browser's IndexedDB and can be
  previewed. No file is uploaded to a server.
- **Milestones:** a checklist saved in browser local storage.
- **Event Log:** workspace actions and periodic read-only telemetry snapshots
  from GFly. Export records as JSON.

## Use the live demo first

The original GFly project is available at https://gfly.site/. Its Room
experiment can be used to confirm that the browser and computer can run the
connectome before modifying the project.

## Publishing FlyCraft without running a local server

This project uses Next.js static export. A completed static build is written to
`web/out/`. That folder can be deployed to a static HTTPS host; the host serves
files but does not run a persistent Node.js application server.

Build requirements:

- Node.js 22 LTS or newer compatible with the pinned Next.js version
- pnpm 10.28.2 (the package manager version recorded in `web/package.json`)

From a terminal in `web/`:

```bash
corepack enable
corepack prepare pnpm@10.28.2 --activate
pnpm install
pnpm build
```

Upload the **contents** of `web/out/` to the root of a static hosting site.
Open the site's HTTPS URL and navigate to `/flycraft/`.

Important: do not open `web/out/index.html` directly using `file://`. GFly uses
Web Workers and fetches model assets; browsers restrict those features for
local files. HTTPS static hosting is the no-localhost way to use the complete
brain simulation.

## Important science and project boundaries

A connectome is a map of neural connections. It does not by itself provide a
complete biological model of memory, language, or HTML programming. The GFly
simulation and any future FlyCraft learning/code-building mechanisms must be
measured and labeled separately.

FlyCraft v0.1 does not yet:

- connect the GFly fly's movement to the new voxel room;
- feed lessons into the connectome;
- detect or classify real escape attempts in the new room;
- generate a Minecraft-like game autonomously.

Those are future milestones, not current features.

## Attribution

The original GFly source, compiled assets, and third-party assets remain in
this package. Preserve the included asset license notices and upstream credits.
The original GFly README identifies the MaleCNS dataset as CC-BY 4.0 and the
flybody rig as Apache-2.0. This FlyCraft starter is an independent modification
and is not an official Google Research or Janelia product.

Original project: https://github.com/SimonSaysGiveMeSmile/gfly
Original live project: https://gfly.site/
