import type { Metadata } from "next";
import { FlyCraftBody } from "./FlyCraftBody";

export const metadata: Metadata = {
  title: "FlyCraft Laboratory",
  description: "A connectome-based fruit fly experiment and coding-learning environment.",
};

export default function FlyCraftPage() {
  return <FlyCraftBody />;
}
