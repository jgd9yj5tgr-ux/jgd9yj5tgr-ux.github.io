"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

/** A visual-only voxel laboratory prototype. It is not connected to the fly yet. */
export function VoxelRoom() {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#9bb7c9");
    scene.fog = new THREE.Fog("#9bb7c9", 22, 42);

    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    camera.position.set(14, 11, 15);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setSize(host.clientWidth, host.clientHeight);
    host.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1.7, 0);
    controls.enableDamping = true;
    controls.maxPolarAngle = Math.PI * 0.48;
    controls.minDistance = 8;
    controls.maxDistance = 28;

    scene.add(new THREE.HemisphereLight("#dceeff", "#4f493d", 2.1));
    const sun = new THREE.DirectionalLight("#fff0d2", 3.0);
    sun.position.set(-7, 13, 8);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    scene.add(sun);

    const materials = new Map<string, THREE.MeshLambertMaterial>();
    const material = (color: string) => {
      let m = materials.get(color);
      if (!m) {
        m = new THREE.MeshLambertMaterial({ color });
        materials.set(color, m);
      }
      return m;
    };
    const cube = new THREE.BoxGeometry(1, 1, 1);
    const addBlock = (x: number, y: number, z: number, color: string, scale = 1) => {
      const mesh = new THREE.Mesh(cube, material(color));
      mesh.position.set(x, y, z);
      mesh.scale.setScalar(scale);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    };

    // Grass-and-stone test pad outside the laboratory.
    for (let x = -8; x <= 8; x++) {
      for (let z = -7; z <= 7; z++) {
        addBlock(x, -0.55, z, (x + z) % 3 === 0 ? "#6d9a50" : "#79a957");
      }
    }

    // Laboratory floor, 12 x 8 blocks.
    for (let x = -5; x <= 5; x++) {
      for (let z = -3; z <= 3; z++) {
        addBlock(x, 0, z, (x + z) % 2 === 0 ? "#8a8f96" : "#777f87");
      }
    }

    // Rear wall and side walls, with a window on the left and a doorway on the right.
    for (let x = -5; x <= 5; x++) {
      for (let y = 1; y <= 4; y++) {
        const isWindow = x >= -3 && x <= -1 && y >= 2 && y <= 3;
        addBlock(x, y, -3.5, isWindow ? "#6bb7d7" : (y === 4 ? "#596a78" : "#788c9a"));
      }
    }
    for (let z = -3; z <= 3; z++) {
      for (let y = 1; y <= 4; y++) {
        addBlock(-5.5, y, z, (z + y) % 2 === 0 ? "#728797" : "#8297a6");
        if (!(z >= 0 && z <= 1 && y <= 3)) {
          addBlock(5.5, y, z, (z + y) % 2 === 0 ? "#728797" : "#8297a6");
        }
      }
    }

    // Door frame and a simple open doorway marker.
    addBlock(5.5, 3.5, 0.5, "#59412f");
    addBlock(5.5, 3.5, 1.5, "#59412f");
    addBlock(5.5, 4.5, 1, "#59412f");
    addBlock(7, 0, 1, "#a2c77a");
    addBlock(8, 0, 1, "#a2c77a");
    addBlock(7, 0, 2, "#a2c77a");
    addBlock(8, 0, 2, "#a2c77a");

    // Desk, computer, monitor, keyboard and chair.
    for (const x of [-1, 0, 1]) addBlock(x, 1, -1.5, "#81552f");
    addBlock(-1, 0, -1.5, "#59402b");
    addBlock(1, 0, -1.5, "#59402b");
    addBlock(0, 2, -2, "#252b31");
    addBlock(0, 2, -1.85, "#69bce5", 0.78);
    addBlock(0, 1.5, -1.5, "#30363c", 0.25);
    addBlock(0, 1, -0.5, "#c8cdd1", 0.45);
    addBlock(0, 0.5, 0.25, "#59402b");
    addBlock(0, 1, 0.25, "#81552f");
    addBlock(0, 1.5, 0.25, "#81552f");

    // Storage shelves with colored block samples.
    for (let y = 1; y <= 3; y += 2) {
      for (let x = 2; x <= 4; x++) addBlock(x, y, -3, "#59402b");
    }
    addBlock(2, 2, -2.5, "#6b9b52", 0.6);
    addBlock(3, 2, -2.5, "#8d8f98", 0.6);
    addBlock(4, 2, -2.5, "#bd9254", 0.6);
    addBlock(2, 4, -2.5, "#5da7c8", 0.6);
    addBlock(3, 4, -2.5, "#a875c4", 0.6);
    addBlock(4, 4, -2.5, "#c36d5d", 0.6);

    // Ceiling-light blocks.
    addBlock(-2, 4.5, 0, "#f4df9c", 0.45);
    addBlock(2, 4.5, 0, "#f4df9c", 0.45);

    const resize = () => {
      if (!host) return;
      const width = Math.max(1, host.clientWidth);
      const height = Math.max(1, host.clientHeight);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    let frame = 0;
    const animate = () => {
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      controls.dispose();
      renderer.dispose();
      cube.dispose();
      materials.forEach((m) => m.dispose());
      host.removeChild(renderer.domElement);
    };
  }, []);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#9bb7c9]">
      <div ref={hostRef} className="h-[420px] w-full sm:h-[520px]" />
      <div className="pointer-events-none absolute left-3 top-3 flex flex-wrap gap-2">
        <span className="rounded-full bg-black/55 px-3 py-1 text-xs font-semibold text-white backdrop-blur">ROOM PROTOTYPE</span>
        <span className="rounded-full bg-black/55 px-3 py-1 text-xs text-white/80 backdrop-blur">Drag to orbit · Scroll to zoom</span>
      </div>
    </div>
  );
}
