"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Runner } from "@/experiments/baseline-room/Runner";
import { VoxelRoom } from "./VoxelRoom";

type Tab = "overview" | "brain" | "room" | "lessons" | "logs";
type EventItem = { id: string; at: string; type: string; detail: string };
type LessonItem = { id: string; name: string; type: string; size: number; savedAt: string; blob: Blob };

type BrainTelemetry = {
  simMs: number;
  realtime: number;
  meanHz: number;
  frames: number;
  fly?: { x: number; y: number; z: number; speed: number; airborne: boolean };
  assay?: string | null;
};

const STORAGE_KEY = "flycraft.events.v1";
const PROGRESS_KEY = "flycraft.milestones.v1";
const DB_NAME = "flycraft-local";
const DB_VERSION = 1;
const LESSON_STORE = "lessons";

const TABS: { id: Tab; label: string; description: string }[] = [
  { id: "overview", label: "Overview", description: "Project status and next milestones" },
  { id: "brain", label: "Brain simulator", description: "Original GFly connectome experiment" },
  { id: "room", label: "Voxel room", description: "Minecraft-style laboratory prototype" },
  { id: "lessons", label: "Lesson library", description: "Local videos and transcript files" },
  { id: "logs", label: "Event log", description: "Saved experiment and workspace activity" },
];

const MILESTONES = [
  { label: "Run the original connectome simulation", status: "complete" },
  { label: "Create a Minecraft-style laboratory", status: "in-progress" },
  { label: "Connect fly movement to the new room", status: "planned" },
  { label: "Add hybrid learning and feedback", status: "planned" },
  { label: "Add HTML lessons and video materials", status: "planned" },
  { label: "Build the Minecraft-inspired game assignment", status: "planned" },
  { label: "Add detailed behavior logging and replay", status: "planned" },
] as const;

function openLessonDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(LESSON_STORE)) db.createObjectStore(LESSON_STORE, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open the local lesson library."));
  });
}

async function getLessons(): Promise<LessonItem[]> {
  const db = await openLessonDb();
  return new Promise<LessonItem[]>((resolve, reject) => {
    const request = db.transaction(LESSON_STORE, "readonly").objectStore(LESSON_STORE).getAll();
    request.onsuccess = () => { db.close(); resolve((request.result as LessonItem[]).sort((a, b) => b.savedAt.localeCompare(a.savedAt))); };
    request.onerror = () => { db.close(); reject(request.error); };
  });
}

async function saveLesson(item: LessonItem): Promise<void> {
  const db = await openLessonDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(LESSON_STORE, "readwrite");
    tx.objectStore(LESSON_STORE).put(item);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

async function deleteLesson(id: string): Promise<void> {
  const db = await openLessonDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(LESSON_STORE, "readwrite");
    tx.objectStore(LESSON_STORE).delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function FlyCraftBody() {
  const [tab, setTab] = useState<Tab>("overview");
  const [events, setEvents] = useState<EventItem[]>([]);
  const [completed, setCompleted] = useState<number[]>([0]);
  const [storageReady, setStorageReady] = useState(false);
  const lastSimSample = useRef(0);

  useEffect(() => {
    try {
      const storedEvents = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as EventItem[];
      const storedProgress = JSON.parse(localStorage.getItem(PROGRESS_KEY) ?? "[0]") as number[];
      setEvents(Array.isArray(storedEvents) ? storedEvents : []);
      setCompleted(Array.isArray(storedProgress) ? storedProgress : [0]);
    } catch {
      setEvents([]);
      setCompleted([0]);
    }
    setStorageReady(true);
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(events.slice(0, 250)));
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(completed));
    } catch {
      // Keep the active session usable if browser storage is disabled or full.
    }
  }, [events, completed, storageReady]);

  const logEvent = useCallback((type: string, detail: string) => {
    const item: EventItem = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, at: new Date().toISOString(), type, detail };
    setEvents((old) => [item, ...old].slice(0, 250));
  }, []);

  const selectTab = (next: Tab) => {
    setTab(next);
    logEvent("workspace", `Opened ${TABS.find((x) => x.id === next)?.label ?? next}.`);
  };

  // GFly exposes a read-only telemetry snapshot on window.__gfly. Sample it
  // periodically while its tab is visible; this does not alter the simulator.
  useEffect(() => {
    if (tab !== "brain") return;
    const timer = window.setInterval(() => {
      const snapshot = (window as unknown as { __gfly?: BrainTelemetry }).__gfly;
      if (!snapshot || snapshot.simMs <= lastSimSample.current) return;
      if (snapshot.simMs - lastSimSample.current < 10000 && lastSimSample.current !== 0) return;
      lastSimSample.current = snapshot.simMs;
      const position = snapshot.fly
        ? `position (${snapshot.fly.x.toFixed(1)}, ${snapshot.fly.y.toFixed(1)}, ${snapshot.fly.z.toFixed(1)}), speed ${snapshot.fly.speed.toFixed(1)} mm/s`
        : "fly position unavailable";
      logEvent("neural telemetry", `t=${(snapshot.simMs / 1000).toFixed(1)} s; mean activity ${snapshot.meanHz.toFixed(2)} Hz; ${position}.`);
    }, 2000);
    return () => window.clearInterval(timer);
  }, [tab, logEvent]);

  const toggleMilestone = (index: number) => {
    setCompleted((old) => old.includes(index) ? old.filter((x) => x !== index) : [...old, index].sort((a, b) => a - b));
    logEvent("project progress", `${completed.includes(index) ? "Unmarked" : "Marked"}: ${MILESTONES[index].label}.`);
  };

  const exportEvents = () => {
    const payload = { project: "FlyCraft", exportedAt: new Date().toISOString(), note: "Workspace and sampled GFly telemetry events. This export does not claim to contain a complete fly trajectory or every neural event.", events };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `flycraft-events-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    logEvent("export", `Exported ${events.length} event records.`);
  };

  return (
    <div className="mx-auto max-w-[1500px] px-4 pb-14 pt-6 sm:px-6 lg:px-10">
      <header className="mb-6 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="t-cap">Connectome experiment workspace · version 0.1</p>
          <h1 className="t-large mt-2">FlyCraft <span className="text-[#8ebc72]">Laboratory</span></h1>
          <p className="t-body mt-3 max-w-2xl">A virtual fly experiment built around the existing GFly connectome simulator, with a voxel room, local lessons, and experiment records.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="fc-tag fc-tag-green"><i /> Brain engine included</span>
          <span className="fc-tag">Browser-based workspace</span>
          <span className="fc-tag">Local data storage</span>
        </div>
      </header>

      <div className="grid gap-4 lg:grid-cols-[230px_minmax(0,1fr)]">
        <aside className="glass h-fit p-3">
          <p className="t-cap px-3 pb-2 pt-1">Workspace</p>
          <nav className="flex gap-1 overflow-x-auto lg:flex-col" aria-label="FlyCraft sections">
            {TABS.map((item) => (
              <button key={item.id} onClick={() => selectTab(item.id)} className={`fc-nav-item ${tab === item.id ? "is-active" : ""}`} aria-current={tab === item.id ? "page" : undefined}>
                <span>{item.label}</span>
                <span className="hidden text-xs text-white/40 xl:inline">{item.description}</span>
              </button>
            ))}
          </nav>
          <div className="mt-4 hidden rounded-xl bg-black/20 p-3 lg:block">
            <p className="t-cap">Current experiment</p>
            <p className="mt-1 text-sm font-semibold">Male fruit fly CNS</p>
            <p className="t-foot mt-1">GFly baseline room · original connectome model</p>
          </div>
        </aside>

        <main className="min-w-0 space-y-4">
          {tab === "overview" && (
            <>
              <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <Metric value="164,740" label="Neurons in the model" detail="Male fly central nervous system" />
                <Metric value="6.24M" label="Standard graph edges" detail="5+ synapse threshold" />
                <Metric value={`${completed.length}/7`} label="Project milestones" detail="Saved in this browser" />
                <Metric value={String(events.length)} label="Recorded events" detail="Up to 250 recent entries" />
              </section>
              <section className="glass p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="t-cap">Start here</p>
                    <h2 className="t-title mt-1">Run the original fly brain</h2>
                    <p className="t-body mt-2 max-w-2xl">The existing GFly simulation is embedded directly below its own workspace tab. It retains its brain-size selector, room view, fly controls, assays, and neural activity panels.</p>
                  </div>
                  <button className="btn-primary" onClick={() => selectTab("brain")}>Open brain simulator →</button>
                </div>
                <div className="mt-5 grid gap-3 md:grid-cols-3">
                  <InfoTile title="Original brain" body="The connectome and worker-based neural simulation are reused from GFly." />
                  <InfoTile title="New environment" body="A Minecraft-inspired room is being prototyped separately before agent control is connected." />
                  <InfoTile title="Learning materials" body="Videos and transcript files can be added to a local browser library." />
                </div>
              </section>
              <section className="glass p-5 sm:p-6">
                <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
                  <div><p className="t-cap">Build roadmap</p><h2 className="t-title mt-1">FlyCraft milestones</h2></div>
                  <p className="t-foot">Progress saves in this browser</p>
                </div>
                <div className="space-y-2">
                  {MILESTONES.map((item, index) => {
                    const checked = completed.includes(index);
                    return (
                      <label key={item.label} className="fc-milestone">
                        <input type="checkbox" checked={checked} onChange={() => toggleMilestone(index)} />
                        <span className="min-w-0 flex-1"><span className={checked ? "line-through text-white/45" : "text-white/90"}>{item.label}</span></span>
                        <span className={`fc-status ${checked ? "done" : item.status === "in-progress" ? "active" : "planned"}`}>{checked ? "Done" : item.status === "in-progress" ? "In progress" : "Planned"}</span>
                      </label>
                    );
                  })}
                </div>
              </section>
            </>
          )}

          {tab === "brain" && (
            <section className="space-y-3">
              <div className="glass flex flex-wrap items-center justify-between gap-3 p-4">
                <div><p className="t-cap">Original GFly experiment</p><h2 className="t-title mt-1">The Room · connectome simulation</h2></div>
                <span className="fc-tag fc-tag-green"><i /> Original neural engine</span>
              </div>
              <div className="glass p-2 sm:p-3"><Runner /></div>
              <p className="t-foot px-1">Telemetry sampling is read-only. This workspace currently records occasional neural activity snapshots; it does not yet detect every movement, door interaction, or escape attempt.</p>
            </section>
          )}

          {tab === "room" && (
            <section className="glass p-4 sm:p-5">
              <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                <div><p className="t-cap">Phase 2 · visual prototype</p><h2 className="t-title mt-1">The voxel laboratory</h2><p className="t-body mt-2 max-w-2xl">A block-built test room with a workstation, shelves, window, and exit. This is a separate scene prototype; the GFly fly does not control it yet.</p></div>
                <span className="fc-tag fc-tag-orange">Not connected to brain yet</span>
              </div>
              <VoxelRoom />
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                <RoomLegend title="Computer station" description="Future HTML lessons and code-building interface." color="bg-sky-400" />
                <RoomLegend title="Exit doorway" description="Future boundary and exploration interactions." color="bg-amber-500" />
                <RoomLegend title="Storage shelves" description="Future inventory and block samples." color="bg-emerald-500" />
              </div>
            </section>
          )}

          {tab === "lessons" && <LessonLibrary onEvent={logEvent} />}

          {tab === "logs" && (
            <section className="glass p-4 sm:p-5">
              <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                <div><p className="t-cap">Local experiment records</p><h2 className="t-title mt-1">Event history</h2><p className="t-foot mt-2">Workspace actions and periodic read-only GFly telemetry samples.</p></div>
                <div className="flex gap-2"><button className="btn" onClick={exportEvents}>Export JSON</button><button className="btn" onClick={() => { setEvents([]); logEvent("log", "Event history cleared."); }}>Clear logs</button></div>
              </div>
              {events.length === 0 ? <EmptyState title="No events yet" body="Open the brain simulator, add lesson materials, or explore the voxel room to begin recording workspace activity." /> : (
                <div className="max-h-[620px] overflow-auto rounded-xl border border-white/10">
                  <table className="w-full text-left text-sm">
                    <thead className="sticky top-0 bg-[#171b20] text-xs uppercase tracking-wide text-white/45"><tr><th className="px-3 py-3">Time</th><th className="px-3 py-3">Event</th><th className="px-3 py-3">Details</th></tr></thead>
                    <tbody>{events.map((item) => <tr key={item.id} className="border-t border-white/5 align-top"><td className="whitespace-nowrap px-3 py-3 text-xs text-white/45">{new Date(item.at).toLocaleString()}</td><td className="whitespace-nowrap px-3 py-3 font-semibold text-white/80">{item.type}</td><td className="px-3 py-3 text-white/65">{item.detail}</td></tr>)}</tbody>
                  </table>
                </div>
              )}
            </section>
          )}
        </main>
      </div>
      <footer className="mt-6 border-t border-white/10 pt-4 text-xs leading-relaxed text-white/40">FlyCraft is an independent experiment built on the GFly project. A connectome is a wiring map, not a complete model of biological learning or human-like programming ability. Engineered learning and code-generation systems will be labeled separately from connectome-derived behavior.</footer>
    </div>
  );
}

function Metric({ value, label, detail }: { value: string; label: string; detail: string }) {
  return <div className="glass p-4"><p className="text-2xl font-semibold tracking-tight text-white">{value}</p><p className="mt-1 text-sm font-semibold text-white/80">{label}</p><p className="t-foot mt-1">{detail}</p></div>;
}

function InfoTile({ title, body }: { title: string; body: string }) {
  return <div className="rounded-xl bg-black/20 p-4"><p className="font-semibold text-white/85">{title}</p><p className="t-foot mt-2">{body}</p></div>;
}

function RoomLegend({ title, description, color }: { title: string; description: string; color: string }) {
  return <div className="flex gap-3 rounded-xl bg-black/20 p-3"><span className={`mt-1 h-3 w-3 shrink-0 rounded-sm ${color}`} /><div><p className="text-sm font-semibold">{title}</p><p className="t-foot mt-1">{description}</p></div></div>;
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return <div className="rounded-xl border border-dashed border-white/15 px-5 py-10 text-center"><p className="font-semibold text-white/75">{title}</p><p className="t-foot mx-auto mt-2 max-w-md">{body}</p></div>;
}

function LessonLibrary({ onEvent }: { onEvent: (type: string, detail: string) => void }) {
  const [lessons, setLessons] = useState<LessonItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [textPreview, setTextPreview] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const selected = useMemo(() => lessons.find((x) => x.id === selectedId) ?? null, [lessons, selectedId]);

  const refresh = useCallback(async () => {
    try {
      const all = await getLessons();
      setLessons(all);
      setSelectedId((current) => current && all.some((x) => x.id === current) ? current : all[0]?.id ?? null);
    } catch {
      setMessage("This browser could not open IndexedDB. Try a current version of Chrome or Edge.");
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  useEffect(() => {
    if (!selected) { setPreviewUrl(null); setTextPreview(""); return; }
    if (selected.type.startsWith("video/")) {
      const url = URL.createObjectURL(selected.blob);
      setPreviewUrl(url);
      setTextPreview("");
      return () => URL.revokeObjectURL(url);
    }
    setPreviewUrl(null);
    if (selected.type === "text/vtt" || selected.type === "text/plain" || /\.(srt|vtt|txt)$/i.test(selected.name)) {
      selected.blob.text().then(setTextPreview).catch(() => setTextPreview("Could not read this text file."));
    } else setTextPreview("This file is saved locally. A viewer for this format has not been added yet.");
  }, [selected]);

  const addFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    setMessage("");
    try {
      for (const file of Array.from(files)) {
        const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const item: LessonItem = { id, name: file.name, type: file.type || "application/octet-stream", size: file.size, savedAt: new Date().toISOString(), blob: file };
        await saveLesson(item);
        onEvent("lesson added", `${file.name} (${formatBytes(file.size)}) saved to this browser's local lesson library.`);
      }
      await refresh();
      setMessage("Saved in this browser. The file is not uploaded to a server.");
    } catch {
      setMessage("Could not save the file. Browser storage may be full or unavailable.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const removeSelected = async () => {
    if (!selected) return;
    const name = selected.name;
    await deleteLesson(selected.id);
    setSelectedId(null);
    await refresh();
    onEvent("lesson removed", `${name} removed from the local lesson library.`);
  };

  return (
    <section className="glass p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div><p className="t-cap">Local browser storage</p><h2 className="t-title mt-1">Lesson library</h2><p className="t-body mt-2 max-w-2xl">Add MP4/WebM lessons and transcript files. Files stay in this browser's IndexedDB; this starter does not send them to a server or claim that the connectome understands video.</p></div>
        <div><input ref={fileRef} className="hidden" type="file" multiple accept="video/mp4,video/webm,video/ogg,.srt,.vtt,.txt,.pdf" onChange={(e) => void addFiles(e.target.files)} /><button className="btn-primary" disabled={busy} onClick={() => fileRef.current?.click()}>{busy ? "Saving…" : "Choose lesson files"}</button></div>
      </div>
      {message && <p className="mb-3 rounded-lg bg-white/5 px-3 py-2 text-sm text-white/65">{message}</p>}
      <div className="grid gap-4 lg:grid-cols-[minmax(220px,0.8fr)_minmax(0,1.5fr)]">
        <div className="space-y-2">
          <p className="t-cap">Saved files ({lessons.length})</p>
          {lessons.length === 0 ? <EmptyState title="Your library is empty" body="Choose a video or transcript file to add your first lesson material." /> : lessons.map((item) => (
            <button key={item.id} onClick={() => { setSelectedId(item.id); onEvent("lesson opened", `Opened ${item.name}.`); }} className={`w-full rounded-xl border p-3 text-left ${selectedId === item.id ? "border-[#8ebc72]/60 bg-[#8ebc72]/10" : "border-white/10 bg-black/20 hover:bg-white/5"}`}>
              <p className="truncate text-sm font-semibold text-white/85">{item.name}</p><p className="t-foot mt-1">{formatBytes(item.size)} · {item.type || "Unknown type"}</p>
            </button>
          ))}
        </div>
        <div className="min-h-[260px] rounded-xl bg-black/25 p-3 sm:p-4">
          {!selected ? <EmptyState title="Select a lesson" body="A video preview or transcript will appear here." /> : (
            <>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div className="min-w-0"><p className="truncate font-semibold">{selected.name}</p><p className="t-foot">Added {new Date(selected.savedAt).toLocaleString()}</p></div><button className="btn" onClick={() => void removeSelected()}>Remove</button></div>
              {previewUrl ? <video key={previewUrl} src={previewUrl} controls className="max-h-[430px] w-full rounded-lg bg-black" /> : <pre className="max-h-[430px] overflow-auto whitespace-pre-wrap rounded-lg bg-black/30 p-3 text-xs leading-relaxed text-white/65">{textPreview || "No preview is available for this file type."}</pre>}
            </>
          )}
        </div>
      </div>
      <p className="t-foot mt-4">Note: local browser storage can be cleared by browser settings. Export/backup for lesson files will be added separately; event-log export does not include video files.</p>
    </section>
  );
}
