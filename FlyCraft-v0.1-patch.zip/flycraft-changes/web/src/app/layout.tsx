import type { Metadata } from "next";
import { Fraunces, Instrument_Sans } from "next/font/google";
import "./globals.css";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

// Two faces: a soft, slightly wonky serif for what the site says, a plain
// grotesk for what it measures. Both self-hosted at build time.
const display = Fraunces({ subsets: ["latin"], axes: ["SOFT", "WONK", "opsz"], variable: "--font-display", display: "swap" });
const sans = Instrument_Sans({ subsets: ["latin"], variable: "--font-text", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL("https://gfly.site"),
  title: { default: "GFly + FlyCraft — a fruit fly connectome laboratory", template: "%s — FlyCraft" },
  description:
    "Explore the GFly fruit fly connectome simulation and the FlyCraft virtual laboratory in your browser.",
  openGraph: {
    title: "GFly",
    description: "164,740 real neurons. Running in your browser.",
    url: "https://gfly.site", siteName: "GFly", type: "website",
    images: [{ url: "/logo.png", width: 512, height: 512, alt: "GFly" }],
  },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="flex min-h-screen flex-col">
        <div className="wash" aria-hidden />
        <SiteHeader />
        <main className="flex-1">{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
