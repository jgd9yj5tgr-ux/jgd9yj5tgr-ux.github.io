# FlyCraft Laboratory — v0.2 update

This patch updates the existing FlyCraft starter while preserving the supplied GFly simulation engine and its compiled connectome assets.

## What's changed in v0.2

- The FlyCraft route is now a focused, single-page **FlyCraft Laboratory** interface. The upstream GFly navigation and footer are hidden on this route.
- The separate visual-only voxel-room prototype is replaced by a voxelized rendering inside GFly's existing `baseline-room` simulation.
- The original GFly `Runner`, worker, connectome loading, body rig, flight controls, brain/retina views, and assays are retained.
- The voxel room is rendered from the same `FURNITURE` world map used by the simulation for collisions, floor height, and simplified visual ray inputs. This keeps the displayed room and simulated environment aligned.
- The visible fly remains the original rigged model loaded by GFly. A small locator halo makes it easier to spot in the room; it does not change the simulated position or physics.
- The browser title and page metadata now say **FlyCraft Laboratory**.

## Scientific and technical boundaries

The original GFly worker currently derives visual input using horizontal ray casts against the 2D room map (`castRay` in `world.ts`). This update makes the voxel visuals and that map describe the same walls, window, desk, chair, shelves, and doorway. It does **not** turn the connectome into a full 3D camera renderer. Height, colour, and every individual block are not yet represented as independent visual pixels in the fly's retina.

The original GFly `Runner` drives the body rig from telemetry emitted by the neural simulation. The same telemetry positions and animates the model in the voxelized `RoomView`; the brain simulation therefore controls the fly in the updated room through GFly's existing worker and frame bus.

The doorway is a visual opening in this milestone. The current upstream world clamps the fly's position inside the arena, so crossing the room boundary and recording an escape are future work.

This project is an independent modification, not an official Google Research or HHMI Janelia product. Preserve upstream license and dataset attribution files.

## Apply through the existing GitHub Actions workflow

The existing workflow expects a repository-root file named `FlyCraft-v0.1-patch.zip` and extracts the `flycraft-changes/web/` folder into `web/` before building. Replace the previous ZIP with this updated ZIP **using that exact filename**. Commit the replacement. The push will trigger the existing cloud build automatically.

No Node.js installation or local server is needed on the user's computer. GitHub Actions performs the build and GitHub Pages serves the static result over HTTPS.
