"use client";

/**
 * The room in 3D. One scene unit is 100 mm. The fly is the flybody rig
 * (Google DeepMind / HHMI Janelia, Apache-2.0) at life size: 3 mm long, so
 * from across the arena it is a speck and the follow camera has to get
 * close. Its legs and wings are choreographed from the simulation's commands.
 */
import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { loadBody, type Body, type BodyKind } from "@/lib/three/body";
import { loadEnvironment } from "@/lib/three/env";
import { FURNITURE, ROOM_H, ROOM_W, ROOM_Z, heightOf } from "./world";
import type { FrameBus } from "./bus";

const U = 0.01;                  // mm -> scene units
const FLY_SCALE = 0.03;          // a 3 mm animal, life size
const FOLLOW_DIST = 0.17;        // 17 mm behind it

export type ViewMode = "orbit" | "follow" | "eye";

export function RoomView({ bus, kind, view, overrides, className }: {
  bus: FrameBus;
  kind: BodyKind;
  view: ViewMode;
  /** Manual joint angles, shared with the body panel. */
  overrides: Map<string, number>;
  className?: string;
}) {
  const host = useRef<HTMLDivElement>(null);
  const viewRef = useRef(view);
  const ovRef = useRef(overrides);
  useEffect(() => { viewRef.current = view; }, [view]);
  useEffect(() => { ovRef.current = overrides; }, [overrides]);

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let disposed = false;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0b0e);
    scene.fog = new THREE.Fog(0x0b0b0e, 20, 44);

    const W = ROOM_W * U, H = ROOM_H * U;
    const camera = new THREE.PerspectiveCamera(46, 1, 0.002, 100);
    camera.position.set(W * 0.5 + 2.6, 2.4, H * 0.92);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(W / 2, 0.2, H * 0.45);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.minDistance = 0.05;
    controls.maxDistance = 26;

    // Light: a warm window on the far wall, a cool fill, soft shadows, and a
    // photographed studio probe (Poly Haven, CC0) for the fly's cuticle.
    loadEnvironment(renderer, "studio").then((env) => { if (!disposed) { scene.environment = env; scene.environmentIntensity = 0.45; } }).catch(() => {});
    scene.add(new THREE.HemisphereLight(0xb9c4ff, 0x141210, 1.1));
    const sun = new THREE.DirectionalLight(0xffe2b0, 2.4);
    sun.position.set(W * 0.4, 8, -4);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -10; sun.shadow.camera.right = 16;
    sun.shadow.camera.top = 12; sun.shadow.camera.bottom = -6;
    sun.shadow.bias = -0.0005;
    scene.add(sun);
    const windowGlow = new THREE.PointLight(0xffd9a0, 30, 14, 2);
    windowGlow.position.set(W * 0.38, 1.6, 0.4);
    scene.add(windowGlow);

    // Minecraft-inspired block laboratory. One block is 100 mm (one scene unit).
    // The room is drawn from FURNITURE, the exact same map used by worker.ts
    // for collision, floor height and its simplified horizontal retinal rays.
    const blockGeo = new THREE.BoxGeometry(1, 1, 1);
    const mats = new Map<string, THREE.MeshStandardMaterial>();
    const mat = (name: string, color: string, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) => {
      const key = `${name}:${color}`;
      let m = mats.get(key);
      if (!m) {
        m = new THREE.MeshStandardMaterial({ color, roughness: 0.92, ...extra });
        mats.set(key, m);
      }
      return m;
    };
    const addBlock = (x: number, y: number, z: number, material: THREE.Material, scale = 1) => {
      const mesh = new THREE.Mesh(blockGeo, material);
      mesh.position.set(x, y, z);
      mesh.scale.setScalar(scale);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    };
    const stoneA = mat("stone-a", "#8a8f96");
    const stoneB = mat("stone-b", "#747d86");
    const grassA = mat("grass-a", "#6d9a50");
    const grassB = mat("grass-b", "#79a957");
    const wallA = mat("wall-a", "#788c9a");
    const wallB = mat("wall-b", "#596a78");
    const wood = mat("wood", "#81552f");
    const woodDark = mat("wood-dark", "#59402b");
    const shelfMat = mat("shelf", "#63472f");
    const glassMat = mat("glass", "#6bb7d7", { transparent: true, opacity: 0.62, emissive: "#245a75", emissiveIntensity: 0.22 });
    const screenMat = mat("screen", "#69bce5", { emissive: "#267da8", emissiveIntensity: 0.85, metalness: 0.15, roughness: 0.35 });
    const darkMat = mat("dark", "#252b31", { metalness: 0.2, roughness: 0.55 });
    const samples = [
      mat("sample-grass", "#6b9b52"), mat("sample-stone", "#8d8f98"),
      mat("sample-wood", "#bd9254"), mat("sample-blue", "#5da7c8"),
      mat("sample-purple", "#a875c4"), mat("sample-red", "#c36d5d"),
    ];

    // Grass pad around the lab, visible through the doorway and windows.
    for (let x = -2; x <= 13; x++) {
      for (let z = -2; z <= 9; z++) {
        if (x >= 0 && x < 12 && z >= 0 && z < 8) continue;
        addBlock(x + 0.5, -0.55, z + 0.5, ((x + z) % 3 === 0) ? grassA : grassB);
      }
    }

    // Stone floor: 12 x 8 blocks, with subtle checker variation.
    for (let x = 0; x < 12; x++) {
      for (let z = 0; z < 8; z++) {
        addBlock(x + 0.5, -0.5, z + 0.5, ((x + z) % 2 === 0) ? stoneA : stoneB);
      }
    }

    // Voxelize walls and obstacles from the simulation's own world map.
    for (const r of FURNITURE) {
      const x0 = Math.floor(r.x / 100), x1 = Math.max(x0 + 1, Math.ceil((r.x + r.w) / 100));
      const z0 = Math.floor(r.y / 100), z1 = Math.max(z0 + 1, Math.ceil((r.y + r.h) / 100));
      if (r.kind === "window") {
        const width = Math.max(0.25, (x1 - x0) - 0.08);
        const pane = new THREE.Mesh(new THREE.BoxGeometry(width, 1.65, 0.14), glassMat);
        pane.position.set((r.x + r.w / 2) * U, 2.15, (r.y + r.h / 2) * U);
        pane.castShadow = false;
        scene.add(pane);
        continue;
      }
      if (r.kind === "wall") {
        const heightBlocks = Math.ceil(ROOM_Z / 100);
        for (let x = x0; x < x1; x++) {
          for (let z = z0; z < z1; z++) {
            for (let y = 0; y < heightBlocks; y++) {
              addBlock(x + 0.5, y + 0.5, z + 0.5, ((x + y + z) % 3 === 0) ? wallB : wallA);
            }
          }
        }
      } else if (r.label === "table") {
        const cx = (r.x + r.w / 2) * U, cz = (r.y + r.h / 2) * U;
        const width = r.w * U, depth = r.h * U;
        const top = new THREE.Mesh(new THREE.BoxGeometry(width, 0.18, depth), wood);
        top.position.set(cx, 0.66, cz);
        top.castShadow = true; top.receiveShadow = true; scene.add(top);
        for (const dx of [-1, 1]) for (const dz of [-1, 1]) {
          const leg = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.65, 0.13), woodDark);
          leg.position.set(cx + dx * (width / 2 - 0.12), 0.325, cz + dz * (depth / 2 - 0.12));
          leg.castShadow = true; scene.add(leg);
        }
      } else if (r.label === "chair") {
        const cx = (r.x + r.w / 2) * U, cz = (r.y + r.h / 2) * U;
        const seat = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.16, 1.05), wood);
        seat.position.set(cx, 0.62, cz); seat.castShadow = true; scene.add(seat);
        const back = new THREE.Mesh(new THREE.BoxGeometry(1.28, 0.72, 0.14), woodDark);
        back.position.set(cx, 1.03, cz + 0.47); back.castShadow = true; scene.add(back);
        for (const dx of [-1, 1]) for (const dz of [-1, 1]) {
          const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 0.12), woodDark);
          leg.position.set(cx + dx * 0.52, 0.275, cz + dz * 0.38); scene.add(leg);
        }
      } else if (r.label === "shelf") {
        const left = x0 + 0.2, right = x1 - 0.2, frontZ = (r.y + r.h / 2) * U;
        for (const x of [left, right]) {
          addBlock(x, 0.9, frontZ, woodDark, 0.7);
          addBlock(x, 1.8, frontZ, woodDark, 0.7);
        }
        const width = Math.max(1.2, right - left);
        for (const y of [0.85, 1.75]) {
          const board = new THREE.Mesh(new THREE.BoxGeometry(width, 0.12, 0.95), shelfMat);
          board.position.set((left + right) / 2, y, frontZ); board.castShadow = true; scene.add(board);
        }
      }
    }

    // Door frame around the opening in the right wall.
    for (const y of [1.5, 2.5]) {
      addBlock(11.5, y, 3.0, woodDark);
      addBlock(11.5, y, 4.9, woodDark);
    }
    for (const z of [3.5, 4.5]) addBlock(11.5, 3.5, z, woodDark);
    // A short path outside the doorway.
    for (let x = 12; x <= 13; x++) for (let z = 3; z <= 5; z++) addBlock(x + 0.5, -0.55, z + 0.5, grassA);

    // Desk details: monitor, stand, keyboard and a small chair back.
    const monitorFrame = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.72, 0.13), darkMat);
    monitorFrame.position.set(6.0, 1.38, 1.48);
    monitorFrame.castShadow = true;
    scene.add(monitorFrame);
    const monitorScreen = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.55, 0.025), screenMat);
    monitorScreen.position.set(6.0, 1.39, 1.56);
    scene.add(monitorScreen);
    addBlock(6.0, 0.98, 1.48, woodDark, 0.35);
    const keyboard = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.055, 0.22), darkMat);
    keyboard.position.set(6.0, 0.83, 2.34);
    scene.add(keyboard);
    // Chair cushion/back rise above the chair footprint.
    addBlock(6.0, 1.1, 3.95, wood, 0.82);
    addBlock(6.0, 1.55, 4.05, woodDark, 0.82);

    // Sample blocks on the storage shelves, echoing the original voxel mockup.
    const samplePositions: [number, number, number, number][] = [
      [8.6, 1.25, 1.4, 0], [9.5, 1.25, 1.4, 1], [10.4, 1.25, 1.4, 2],
      [8.6, 2.15, 1.4, 3], [9.5, 2.15, 1.4, 4], [10.4, 2.15, 1.4, 5],
    ];
    for (const [x, y, z, index] of samplePositions) addBlock(x, y, z, samples[index], 0.62);

    // Soft overhead lights make the block-built lab easy to read.
    const ceilingLamp = mat("lamp", "#f4df9c", { emissive: "#e4c36d", emissiveIntensity: 0.75 });
    addBlock(3.5, 3.7, 4.0, ceilingLamp, 0.38);
    addBlock(8.5, 3.7, 4.0, ceilingLamp, 0.38);

    // The threat: a dark disc that grows as it closes in.
    const threat = new THREE.Mesh(
      new THREE.SphereGeometry(1, 32, 24),
      new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.4, metalness: 0.2 }),
    );
    threat.castShadow = true;
    threat.visible = false;
    scene.add(threat);
    const threatRim = new THREE.Mesh(
      new THREE.SphereGeometry(1.02, 32, 24),
      new THREE.MeshBasicMaterial({ color: 0xff453a, transparent: true, opacity: 0.35, side: THREE.BackSide }),
    );
    threat.add(threatRim);

    // Trail, in three dimensions now.
    const TRAIL_MAX = 900;
    const trailPos = new Float32Array(TRAIL_MAX * 3);
    const trailCol = new Float32Array(TRAIL_MAX * 3);
    const trailGeo = new THREE.BufferGeometry();
    trailGeo.setAttribute("position", new THREE.BufferAttribute(trailPos, 3).setUsage(THREE.DynamicDrawUsage));
    trailGeo.setAttribute("color", new THREE.BufferAttribute(trailCol, 3).setUsage(THREE.DynamicDrawUsage));
    trailGeo.setDrawRange(0, 0);
    const trail = new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.9 }));
    scene.add(trail);

    // Ground shadow disc so altitude reads even in the free view.
    const shadowDisc = new THREE.Mesh(
      new THREE.CircleGeometry(0.5 * FLY_SCALE / 1.8, 32),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35, depthWrite: false }),
    );
    shadowDisc.rotation.x = -Math.PI / 2;
    scene.add(shadowDisc);

    // The fly: a rigged body, choreographed from the simulation's commands.
    const flyGroup = new THREE.Group();
    flyGroup.rotation.order = "YZX";
    scene.add(flyGroup);
    const flyLight = new THREE.PointLight(0xdfe8ff, 0.004, 0.06, 2);
    flyLight.position.set(0.02, 0.05, 0.02);
    flyGroup.add(flyLight);
    // The body stays at the source model's life-size scale. This larger halo
    // is only a visual locator so the tiny fly remains findable in the blocks.
    const locator = new THREE.Mesh(
      new THREE.TorusGeometry(0.105, 0.008, 6, 28),
      new THREE.MeshBasicMaterial({ color: 0xa8e58a, transparent: true, opacity: 0.72 }),
    );
    locator.rotation.x = Math.PI / 2;
    locator.position.y = 0.035;
    flyGroup.add(locator);
    const placeholder = new THREE.Mesh(new THREE.SphereGeometry(0.015, 12, 8), new THREE.MeshStandardMaterial({ color: 0xff453a }));
    flyGroup.add(placeholder);
    let body: Body | null = null;
    let standHeight = FLY_SCALE * 0.18;
    const head = new THREE.Object3D();             // where the eye view sits
    flyGroup.add(head);
    loadBody(kind).then((b) => {
      if (disposed) { b.dispose(); return; }
      body = b;
      b.setShadow(true);
      b.root.scale.setScalar(FLY_SCALE);
      // Stand on the feet.
      standHeight = -b.footY * FLY_SCALE + 0.005;
      b.root.position.y = standHeight;
      // Just in front of the head, between the eyes.
      head.position.set(0.56 * FLY_SCALE, b.headY * FLY_SCALE + standHeight + 0.01, 0);
      flyGroup.remove(placeholder);
      flyGroup.add(b.root);
    }).catch((e) => console.error(e));

    let latest: Parameters<Parameters<FrameBus["on"]>[0]>[0]["data"] | null = null;
    const off = bus.on((f) => {
      const { fly, threat: th, trail: tr } = f.data;
      latest = f.data;
      flyGroup.position.set(fly.x * U, fly.z * U, fly.y * U);
      flyGroup.rotation.set(fly.roll, -fly.heading, fly.pitch);
      shadowDisc.position.set(fly.x * U, 0.0005, fly.y * U);
      const s = Math.max(0.5, 1.2 - fly.z * U * 0.4);
      shadowDisc.scale.setScalar(s);
      (shadowDisc.material as THREE.MeshBasicMaterial).opacity = Math.max(0.06, 0.4 - fly.z * U * 0.2);

      if (th.active && th.size > 0.01) {
        const d = 1.5;                                  // 150 mm out from the fly
        const rad = Math.max(0.03, Math.tan(th.size / 2) * d);
        threat.visible = true;
        threat.scale.setScalar(rad);
        threat.position.set(
          fly.x * U + Math.cos(th.bearing) * d, fly.z * U + standHeight + rad * 0.6, fly.y * U + Math.sin(th.bearing) * d,
        );
      } else {
        threat.visible = false;
      }

      const n = Math.min(TRAIL_MAX, Math.floor(tr.length / 3));
      for (let i = 0; i < n; i++) {
        trailPos[i * 3] = tr[i * 3] * U; trailPos[i * 3 + 1] = tr[i * 3 + 2] * U + 0.002; trailPos[i * 3 + 2] = tr[i * 3 + 1] * U;
        const a = 0.08 + 0.92 * (i / Math.max(1, n));
        const air = tr[i * 3 + 2] > 5;
        trailCol[i * 3] = (air ? 0.25 : 0.19) * a; trailCol[i * 3 + 1] = (air ? 0.78 : 0.82) * a; trailCol[i * 3 + 2] = (air ? 0.88 : 0.35) * a;
      }
      (trailGeo.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
      (trailGeo.getAttribute("color") as THREE.BufferAttribute).needsUpdate = true;
      trailGeo.setDrawRange(0, n);
    });

    const resize = () => {
      const w = el.clientWidth, h = el.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(el);
    resize();

    const tmpTarget = new THREE.Vector3(), tmpPos = new THREE.Vector3(), tmpDir = new THREE.Vector3();
    const homePos = camera.position.clone(), homeTarget = controls.target.clone();
    let lastView: ViewMode | null = null;
    let raf = 0, last = performance.now();
    // A small hook so the camera can be checked from outside.
    (window as unknown as { __gflyRoom?: unknown }).__gflyRoom = { camera, controls, flyGroup };
    const tick = () => {
      const now = performance.now();
      const dt = (now - last) / 1000; last = now;

      if (body && latest) {
        const fly = latest.fly;
        body.mode = fly.airborne ? "fly" : fly.speed > 2 ? "walk" : "idle";
        body.speed = Math.min(1, fly.speed / 75);
        body.turn = Math.max(-1, Math.min(1, fly.turn / 4));
        body.overrides.clear();
        for (const [k, v] of ovRef.current) body.overrides.set(k, v);
        body.update(dt);
      }

      const mode = viewRef.current;
      if (mode !== lastView && (latest || mode !== "follow")) {
        controls.enabled = mode !== "eye";
        body?.setVisible(mode !== "eye");
        camera.fov = mode === "eye" ? 105 : 46;
        camera.updateProjectionMatrix();
        if (mode === "follow") {
          // Come in close behind the animal, a little above it.
          tmpDir.subVectors(camera.position, controls.target).setY(0).setLength(FOLLOW_DIST);
          controls.target.copy(flyGroup.position).setY(flyGroup.position.y + standHeight);
          camera.position.copy(controls.target).add(tmpDir).setY(flyGroup.position.y + standHeight + FOLLOW_DIST * 0.75);
        } else if (mode === "orbit") {
          camera.position.copy(homePos); controls.target.copy(homeTarget);
        }
        lastView = mode;
      }
      if (mode === "follow") {
        // Keep whatever orbit offset the person chose, but track the fly,
        // and never let the camera leave the box.
        tmpTarget.copy(flyGroup.position).setY(flyGroup.position.y + standHeight);
        tmpDir.subVectors(tmpTarget, controls.target);
        controls.target.add(tmpDir);
        camera.position.add(tmpDir);
        // Stay within a band of the follow distance (the wheel can zoom a little).
        tmpDir.subVectors(camera.position, controls.target);
        const len = tmpDir.length();
        const want = Math.min(FOLLOW_DIST * 2.2, Math.max(FOLLOW_DIST * 0.6, len));
        if (Math.abs(want - len) > 1e-6) camera.position.copy(controls.target).add(tmpDir.setLength(want));
        camera.position.x = Math.min(W - 0.18, Math.max(0.18, camera.position.x));
        camera.position.z = Math.min(H - 0.18, Math.max(0.18, camera.position.z));
        camera.position.y = Math.min(ROOM_Z * U - 0.08, Math.max(0.012, camera.position.y));
        controls.update();
      } else if (mode === "eye") {
        head.getWorldPosition(tmpPos);
        camera.position.lerp(tmpPos, Math.min(1, dt * 14));
        tmpDir.set(1, 0, 0).applyQuaternion(flyGroup.quaternion);
        tmpTarget.copy(tmpPos).add(tmpDir);
        camera.lookAt(tmpTarget);
        camera.up.set(0, 1, 0);
      } else {
        controls.update();
      }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      off(); ro.disconnect(); controls.dispose();
      if (body) { flyGroup.remove(body.root); body.dispose(); }
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry && m.geometry !== blockGeo) m.geometry.dispose();
        if (m.material && !Array.isArray(m.material) && ![...mats.values()].includes(m.material as THREE.MeshStandardMaterial)) {
          (m.material as THREE.Material).dispose();
        }
      });
      blockGeo.dispose();
      mats.forEach((m) => m.dispose());
      renderer.dispose();
      el.removeChild(renderer.domElement);
    };
  }, [bus, kind]);

  return <div ref={host} className={className} />;
}
