"use client";

import { Runner } from "@/experiments/baseline-room/Runner";

export function FlyCraftBody() {
  return (
    <div className="mx-auto w-full max-w-[1600px] px-3 pb-10 pt-5 sm:px-6 lg:px-8">
      <header className="mb-5 flex flex-col gap-2 sm:mb-6">
        <p className="t-cap tracking-[0.22em]">CONNECTOME EXPERIMENT</p>
        <h1 className="t-large mt-1">FlyCraft <span className="text-[#8ebc72]">Laboratory</span></h1>
        <p className="t-body max-w-3xl">A simulated fruit fly, its connectome-driven behavior, and a shared voxel laboratory environment.</p>
      </header>
      <section className="glass p-2 sm:p-3">
        <Runner />
      </section>
      <p className="t-foot mt-4 px-1">The fly body, movement, collision map, and simplified visual ray inputs share the same room layout. This is a research simulation, not a complete biological fly brain.</p>
    </div>
  );
}
