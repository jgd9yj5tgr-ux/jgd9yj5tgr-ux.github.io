import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Build a static site that can be deployed to static hosting without a
  // persistent Node.js application server. Browser workers still require an
  // HTTP(S) origin; opening index.html directly from file:// is not supported.
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
