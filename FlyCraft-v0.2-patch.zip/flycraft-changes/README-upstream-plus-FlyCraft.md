# FlyCraft Laboratory

FlyCraft is an independent browser-based experiment built on the supplied GFly fruit-fly connectome simulator.

## v0.2

The FlyCraft route is a focused laboratory page. It retains GFly's connectome worker and rigged fly model, while rendering the existing simulation room as a Minecraft-inspired voxel laboratory. The displayed room and the worker's collision/raycast map share the same world layout.

The model's position and animation come from the existing simulation telemetry. Neural visual input remains the upstream simplified horizontal ray-cast model; the voxel scene is not yet rendered as full-resolution camera input for the retina. The doorway is visual only in this version because the upstream arena clamps the fly inside its world bounds.

## Build and hosting

The Next.js app uses static export. GitHub Actions installs dependencies, builds `web/out`, and publishes it to GitHub Pages. The user does not need Node.js or a local server to open the hosted version.

## Upstream

Original project: https://github.com/SimonSaysGiveMeSmile/gfly
Original demonstration: https://gfly.site/

The original GFly source, connectome files, body rig, and third-party assets retain their respective upstream licenses and notices. FlyCraft is not an official Google Research or HHMI Janelia product.
